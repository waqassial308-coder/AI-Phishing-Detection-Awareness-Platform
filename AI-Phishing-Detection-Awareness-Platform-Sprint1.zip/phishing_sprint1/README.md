# AI-Powered Phishing Detection & Awareness Platform

Sprint 1 establishes the initial technical structure for a team cybersecurity project focused on phishing detection and security awareness.

## Initial modules
- AWS Lambda phishing analysis API
- Email preprocessing
- Suspicious URL detection
- Phishing simulation structure
- User risk scoring
- Database schema planning
- Awareness dashboard metrics
- Scan history and testing

## Planned AWS services
AWS Lambda, SageMaker, DynamoDB, SES and QuickSight.

## Sprint 1 status
An initial Lambda-based phishing analysis proof of concept has been created and tested in AWS Academy. Later sprints will add datasets, trained machine-learning models, persistent cloud storage, simulations and analytics.
